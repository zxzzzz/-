/**
 * Created by 庄小厮 on 2017-05-20.
 */
function button1click() {
    document.location = 'http://localhost:63342/wifi/onion.html';
}