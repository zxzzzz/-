package zx;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.function.IntToDoubleFunction;

import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

//��������
public class AnalysisUnit {
	private static final int JUMP = 2;// ��������
	private static final int DEEP = 3;// �������

	// �����յ���json���뵽���ݿ�
	public static void main(String[] args) {
		DriverUnit.connectDB();
		System.out.println("��������");
		clientActivity();
		isNew();
}

	// ͳ���и߻�Ծ�ȵ���������
	public static HashMap<String, Integer> visitCycle() {
		HashMap<String, Integer> visit = new HashMap<String, Integer>();
		String visitString = "Select * from table2 where activity between 3 and 4";
		try {
			ResultSet set = DriverUnit.stmt.executeQuery(visitString);
			while (set.next()) {
				String mac = set.getString("mac");
				int cycle = set.getInt("visitCycle");
				visit.put(mac, cycle);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return visit;
	}

	// ͳ�ƿ����� 24Сʱ
	public static Integer[] clientFlow() {
		Integer[] client = new Integer[24];
		String clientQ = "Select * from table1";
		for (int i = 0; i < client.length; i++) {
			client[i] = 0;
		}
		int i = 0;
		int count = 0;
		try {
			ResultSet set = DriverUnit.stmt.executeQuery(clientQ);
			count = set.getRow();
			System.out.println("��¼����" + count);
			while (set.next()) {
				int c = set.getInt("clientFlow");
				client[i++] = c;
				System.out.println("clientFlow" + c);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return client;
	}

	// ͳ������� 24Сʱ
	public static Integer[] shopFlow() {
		Integer[] shop = new Integer[24];
		String clientQ = "Select * from table1";
		for (int i = 0; i < shop.length; i++) {
			shop[i] = 0;
		}
		int i = 0;
		int count = 0;
		try {
			ResultSet set = DriverUnit.stmt.executeQuery(clientQ);
			count = set.getRow();
			System.out.println("��¼����" + count);
			while (set.next()) {
				int c = set.getInt("clientFlow");
				shop[i++] = c;
				System.out.println("shopClient" + c);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return shop;
	}

	// ͳ������� 24Сʱ
	public static Integer[] shopInFlow() {
		Integer[] shop = new Integer[24];
		String clientQ = "Select * from table1";
		for (int i = 0; i < shop.length; i++) {
			shop[i] = 0;
		}
		int i = 0;
		int count = 0;
		try {
			ResultSet set = DriverUnit.stmt.executeQuery(clientQ);
			count = set.getRow();
			System.out.println("��¼����" + count);
			while (set.next()) {

				int c = set.getInt("shopInFlow");
				shop[i++] = c;
				System.out.println("shopClient" + c);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return shop;
	}

	// ��/�Ͽͻ�
	public static Integer[] isNew() {
		String newS = "Select * from table2";
		ResultSet set;
		try {
			set = DriverUnit.stmt.executeQuery(newS);
			int newClient = 0;
			int oldClient = 0;
			while (set.next()) {
				int temp = set.getInt("newClient");
				if (temp == 0) {

					newClient++;
					System.out.println("�¿ͻ�");
				} else {
					oldClient++;
					System.out.println("�Ͽͻ�");
				}

			}
			Integer[] os = new Integer[2];
			os[0] = newClient;
			os[1] = oldClient;
			System.out.println("�¿ͻ�:" + newClient + "  �Ͽͻ�:" + oldClient);
			return os;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	// �ͻ���Ծ��
	// �߻�Ծ��:4
	// �л�Ծ��:3
	// �ͻ�Ծ��:2
	// ��˯��Ծ��:1
	public static Integer[] clientActivity() {
		String activityS = "Select activity from table2 ";

		Integer[] activity = new Integer[4];
		for (int i = 0; i < activity.length; i++) {
			activity[i] = 0;
		}
		try {
			ResultSet resultSet = DriverUnit.stmt.executeQuery(activityS);
			while (resultSet.next()) {
				int temp = resultSet.getInt(1);
				switch (temp) {
				case 4:
					activity[0]++;
					System.out.println("�߻�Ծ��");
					break;
				case 3:
					activity[1]++;
					System.out.println("�л�Ծ��");
					break;
				case 2:
					activity[2]++;
					System.out.println("�ͻ�Ծ��");
					break;
				case 1:
					activity[3]++;
					System.out.println("��˯��Ծ��");
					break;

				default:
					break;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("��Ծ�ȷֱ�Ϊ:" + activity[0] + "," + activity[1] + ","
				+ activity[2] + "," + activity[3]);
		return activity;
	}

	// ��jsonתΪWifiBean
	public static WifiBean convertJSON(HttpServletRequest request) {
		BufferedReader reader;
		try {
			reader = request.getReader();
			StringBuilder builder = new StringBuilder();
			String json;
			while ((json = reader.readLine()) != null) {
				builder.append(json);
				String json1 = builder.toString();
				String targetJson = json1.substring(5);

				System.out.println("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"
						+ targetJson);
				JSONObject jsonObject = JSONObject.fromObject(targetJson);
				WifiBean wifiBean = new WifiBean();
				// wifiBean.setAddr(jsonObject.getString("addr"));
				wifiBean.setTime(jsonObject.getString("time"));
				JSONArray jsonArray = jsonObject.getJSONArray("data");
				ArrayList<DataBean> dataBeans = new ArrayList<DataBean>();
				for (int i = 0; i < jsonArray.size(); i++) {
					JSONObject item = jsonArray.getJSONObject(i);
					DataBean dataBean = new DataBean();
					String mac = item.getString("mac");
					// ����MAC��sql�Ĳ�������в��ܴ�ð��
					mac = mac.replace(":", "");
					System.out.println("MACVVV" + mac);

					String range = item.getString("range");
					float realRange = Float.parseFloat(range);
					String rssi = item.getString("rssi");
					int realRssi = Integer.parseInt(rssi);
					dataBean.setMac(mac);
					dataBean.setRange(realRange);
					dataBean.setRssi(realRssi);
					dataBeans.add(dataBean);

				}
				wifiBean.setData(dataBeans);
				return wifiBean;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;

		}
		return null;

	}

	// פ��ʱ�� table2�����һСʱ�ͻ���פ��ʱ��
	public static HashMap<String, Integer> shopTime() {
		ArrayList<String> macs = new ArrayList<String>();
		HashMap<String, Integer> stay = new HashMap<String, Integer>();
		Timestamp timestamp1 = new Timestamp(System.currentTimeMillis());
		System.out.println("timestamp1:" + timestamp1);
		Timestamp timestamp2 = new Timestamp(System.currentTimeMillis());
		timestamp2.setHours(timestamp2.getHours() - 1);
		timestamp2.setMinutes(0);
		timestamp2.setSeconds(0);
		System.out.println("shopTime.timestamp1:" + timestamp1
				+ "  shopTime.timestamp2:" + timestamp2);
		String string = "select * from table2 where lastTime between ? and ?";
		// ��ѯ���һСʱ��MAC
		try {
			PreparedStatement preparedStatement = DriverUnit.conn
					.prepareStatement(string);
			preparedStatement.setTimestamp(2, timestamp1);
			preparedStatement.setTimestamp(1, timestamp2);
			ResultSet set = preparedStatement.executeQuery();
			while (set.next()) {
				String mac = set.getString("mac");
				System.out.println("shopTime.mac:" + mac);
				macs.add(mac);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ����ÿһ����Ҫ��ѯ��mac��פ��ʱ�� �����һ������-��һ������
		System.out.println("mac.size():" + macs.size());
		for (int i = 0; i < macs.size(); i++) {
			String string2 = "select * from sumtable where mac='"
					+ macs.get(i).toString() + "' and time between ? and ?";

			try {
				// ResultSet set = DriverUnit.stmt.executeQuery(string2);
				PreparedStatement preparedStatement = DriverUnit.conn
						.prepareStatement(string2);
				preparedStatement.setTimestamp(1, timestamp2);
				preparedStatement.setTimestamp(2, timestamp1);
				ResultSet set = preparedStatement.executeQuery();
				Timestamp start=null;
				Timestamp end=null;
				int startM;
				int endM;
				if (set.next()) {
					start = set.getTimestamp("time");
					startM = start.getMinutes();
					System.out.println("start:" + start);
					if (set.last()) {
						end = set.getTimestamp("time");
						System.out.println("end:" + end.toString());
						endM = end.getMinutes();
					} else {
						endM = 60;
					}

					int stayTime = endM - startM;
					if (start.getHours() < end.getHours()) {
							stayTime+=60;
					}
					System.out.println("mac:"+macs.get(i)+"stayTime=" + stayTime);
					stay.put(macs.get(i), stayTime);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// ���±�3
		System.out.println("��ʼ����table3");
		updateTable3(stay);
		return stay;
	}

	// ������һСʱ���û�פ��ʱ��/������/�����
	public static void updateTable3(HashMap<String, Integer> stay) {
		System.out.println("����updateTable3");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		ArrayList<Table3> table3s = new ArrayList<Table3>();
		Set keys = stay.keySet();
		Iterator iterator = keys.iterator();
		while (iterator.hasNext()) {
			
			Object key = iterator.next();
			int stayTime = (int) stay.get(key);
			System.out.println("פ��ʱ��:"+stayTime);
			Table3 table3  = new Table3();
			table3.setTime(timestamp);
			table3.setMac(key.toString());
			System.out.println("mac�ĳ���"+key.toString());
			table3.setStayTime(stayTime);
			// ����
			if (stayTime < JUMP) {
				table3.setJump(true);
			} else {
				table3.setJump(false);
			}
			// ���
			if (stayTime > DEEP) {
				table3.setDeep(true);
			} else {
				table3.setDeep(false);
			}
			table3s.add(table3);
		}
		System.out.println("table3s�ĳ���:"+table3s.size());
		// ����table3
		for (int i = 0; i < table3s.size(); i++) {
			String temp = "insert into table3 values(?,?,?,?,?)";
			try {
				PreparedStatement preparedStatement = DriverUnit.conn
						.prepareStatement(temp);
				preparedStatement.setTimestamp(1, table3s.get(i).getTime());
				preparedStatement.setString(2, table3s.get(i).getMac());
				preparedStatement.setInt(3, table3s.get(i).getStayTime());
				preparedStatement.setBoolean(4, table3s.get(i).isJump());
				preparedStatement.setBoolean(5, table3s.get(i).isDeep());
				preparedStatement.executeUpdate();
				System.out.println("���³ɹ�");
				

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}

	}

	// ������
	public static Integer[] jump() {
		String newS = "Select * from table3";
		ResultSet set;
		try {
			set = DriverUnit.stmt.executeQuery(newS);
			int jump = 0;
			int noJump = 0;
			while (set.next()) {
				if (set.getBoolean("jump")) {
					jump++;
				} else {
					noJump++;
				}
			}
			System.out.println("������:"+jump);
			System.out.println("��������:"+noJump);
			Integer[] jump1 = new Integer[2];
			jump1[0]=(Integer)((jump*100)/(jump+noJump));
			jump1[1]=100-jump1[0];
			
			System.out.println("������:"+jump1[0]+"��������:"+jump1[1]);
			return jump1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// �����
	public static Integer[] deepVisit() {
		String newS = "Select * from table3";
		ResultSet set;
		try {
			set = DriverUnit.stmt.executeQuery(newS);
			int deep = 0;
			int noDeep = 0;
			while (set.next()) {
				if (set.getBoolean("deep")) {
					deep++;
				} else {
					noDeep++;
				}
			}
			Integer[] deep1 = new Integer[2];
			deep1[0] = deep;
			deep1[1] = noDeep;
			// System.out.println("�¿ͻ�:"+newClient+"  �Ͽͻ�:"+oldClient);
			return deep1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
