package zx;

import java.sql.Date;
import java.sql.Timestamp;

//�����ű������ݽṹ:פ��ʱ��ͳ�Ʊ�
public class Table3 {
	Timestamp time;//��ʼʱ��
	String mac;//MAC
	int  stayTime;//פ��ʱ��
	boolean jump;//�Ƿ�����
	boolean deep;//�Ƿ����
	public Timestamp getTime() {
		return time;
	}
	public void setTime(Timestamp time) {
		this.time = time;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public int getStayTime() {
		return stayTime;
	}
	public void setStayTime(int stayTime) {
		this.stayTime = stayTime;
	}
	public boolean isJump() {
		return jump;
	}
	public void setJump(boolean jump) {
		this.jump = jump;
	}
	public boolean isDeep() {
		return deep;
	}
	public void setDeep(boolean deep) {
		this.deep = deep;
	}
	

}
