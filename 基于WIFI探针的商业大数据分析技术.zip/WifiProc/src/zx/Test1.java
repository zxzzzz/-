package zx;

import java.io.IOException;
import java.io.ObjectOutputStream.PutField;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class Test1
 * 
 * ��ǰ�η���json����
 * 
 * 
 */
@WebServlet("/Test1")
public class Test1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Test1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DriverUnit.connectDB();
	    Integer [][] data=new Integer[7][];
	    data[0] =AnalysisUnit.clientFlow();//������
	    data[1]=AnalysisUnit.shopFlow();//�����
	    data[2]=AnalysisUnit.shopInFlow();//�����
	    data[3]=AnalysisUnit.isNew();//���Ͽͻ�
	    data[4]=AnalysisUnit.clientActivity();//��Ծ��
	    HashMap<String, Integer> visitClcy=AnalysisUnit.visitCycle();//��������
	    HashMap<String, Integer> stayTime=AnalysisUnit.shopTime();//פ��ʱ��
	    data[5]=AnalysisUnit.jump();//����
	    data[6]=AnalysisUnit.deepVisit();//���
	    
	    
//	    {
//	    	data1:[
//	    	       {client:2,shop:3,shopIn:4}
//	    	       {}
//	    	       {}
//	    	       ],
//	    	old:3,
//	    	new :4,
	    
//	    	jump:4,
//	    	noJump:4,
//	    	deep:2
//	    	noDeep:5,
//	    	visitCycle:[{mac:ss,visitTime:3},......],
//	    	stayTime:[{mac:ss,shopTime:3}]
//	    	
	    		
//	    	activity:[high:2,mid:3,low:4,sleep:6]
//	    }
	    JSONObject sumJsonObject=new JSONObject();
	    JSONArray jsonArray=new JSONArray();
	    
	    for (int i = 0; i < 24; i++) {
	    	JSONObject j=new JSONObject();
	    	j.put("client", data[0][i]);
	    	j.put("shop", data[1][i]);
	    	j.put("shopIn", data[2][i]);
	        jsonArray.add(j);
	 		
	    }
	    
	    //������������
	    JSONArray cycle=new JSONArray();
	    Set keys = visitClcy.keySet();
		Iterator iterator = keys.iterator();
		while (iterator.hasNext()) {
			Object key = iterator.next();
			int s = (int) visitClcy.get(key);
			String mString=key.toString();
			System.out.println("mac:"+mString+" visitTime:"+s);
			JSONObject jsonObject=new JSONObject();
			jsonObject.put("mac", mString);
			jsonObject.put("visitTime", s);
			cycle.add(jsonObject);
		}
		sumJsonObject.put("visitCycle", cycle);
		
		//����פ��ʱ��
		JSONArray shop=new JSONArray();
	    Set key2 = stayTime.keySet();
		Iterator iterator1 = key2.iterator();
		while (iterator1.hasNext()) {
			System.out.println("stayTime��Ϊ��");
			Object key = iterator1.next();
			System.out.println("key:"+key.toString());
			int s = (int) stayTime.get(key);
			String mString=key.toString();
			JSONObject jsonObject=new JSONObject();
			jsonObject.put("mac", mString);
			jsonObject.put("shopTime", s);
			System.out.println("mac:"+mString+" shopTime:"+s);
			shop.add(jsonObject);
		}
		System.out.println("���յ�json������:"+data[5][0]);
		System.out.println("���յ�json��������:"+data[5][1]);
		sumJsonObject.put("stayTime", shop);
	    sumJsonObject.put("data1", jsonArray);
	    sumJsonObject.put("old", data[3][1]);
	    sumJsonObject.put("newClient", data[3][0]);
	    sumJsonObject.put("deep",data[6][0]);
	    sumJsonObject.put("nodeep",data[6][1]);
	    sumJsonObject.put("jump",data[5][0]);
	    sumJsonObject.put("noJump",data[5][1]);
	    //���ӻ�Ծ��
	    JSONArray jArray=new JSONArray();
	    JSONObject jObject=new JSONObject();
	    jObject.put("high",data[4][0]);
	    jObject.put("mid", data[4][1]);
	    jObject.put("low",data[4][2]);
	    jObject.put("sleep", data[4][3]);
	    jArray.add(jObject);
	    sumJsonObject.put("activity", jArray);
	    System.out.println("Ҫ���͵�JSON����:"+sumJsonObject.toString());
		response.getWriter().write(sumJsonObject.toString());
		response.getWriter().flush();;
	}

}
