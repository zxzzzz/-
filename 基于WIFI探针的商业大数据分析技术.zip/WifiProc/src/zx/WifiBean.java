
package zx;
import java.sql.Date;
import java.util.List;

//jsonBean 
public class WifiBean {

	private String time;
    private String addr;//��ַ
    private List<DataBean> data;//���ָ��
    public void setTime(String time) {
         this.time = time;
     }
     public String  getTime() {
         return time;
     }

    public void setAddr(String addr) {
         this.addr = addr;
     }
     public String getAddr() {
         return addr;
     }

    public void setData(List<DataBean> data) {
         this.data = data;
     }
     public List<DataBean> getData() {
         return data;
     }
     

}