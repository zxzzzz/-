package zx;


import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class HelloServlet
 */
@WebServlet("/HelloServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MainServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			doPost(request, response);
//		
//		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request,response);
		 response.setContentType("text/json;charset=utf-8");  

			response.setCharacterEncoding("GBK");

		        /** ������Ӧͷ����ajax������� **/  
		        response.setHeader("Access-Control-Allow-Origin", "*");  
		        /* �Ǻű�ʾ���е��������󶼿��Խ��ܣ� */  
		        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
		        DriverUnit.connectDB();
		        Integer [][] data=new Integer[4][];
		        data[0] =AnalysisUnit.clientFlow();
		        data[1]=AnalysisUnit.shopFlow();
		        data[2]=AnalysisUnit.shopInFlow();
		        data[3]=AnalysisUnit.isNew();
		        data[4]=AnalysisUnit.clientActivity();
//		        {
//		        	data1:[
//		        	       {client:2,shop:3,shopIn:4}
//		        	       {}
//		        	       {}
//		        	       ],
//		        	old:3,
//		        	new :4,
//		        	activity:[high:2,mid:3,low:4,sleep:6]
//		        }
		        JSONObject sumJsonObject=new JSONObject();
		        JSONArray jsonArray=new JSONArray();
		        for (int i = 0; i < data.length; i++) {
					
				}
		        for (int i = 0; i < 24; i++) {
		        	JSONObject j=new JSONObject();
		        	j.put("client", data[0][i]);
		        	j.put("shop", data[1][i]);
		        	j.put("shopIn", data[2][i]);
		             jsonArray.add(j);
		     		}
		        sumJsonObject.put("data1", jsonArray);
		        sumJsonObject.put("old", data[3][1]);
		        sumJsonObject.put("new", data[3][0]);
		        JSONArray jArray=new JSONArray();
		        JSONObject jObject=new JSONObject();
		        jObject.put("high",data[4][0]);
		        jObject.put("mid", data[4][1]);
		        jObject.put("low",data[4][2]);
		        jObject.put("sleep", data[4][3]);
		        jArray.add(jObject);
		        sumJsonObject.put("activity", jArray);
		        PrintWriter writer=response.getWriter();
		        writer.write(sumJsonObject.toString());
		        writer.flush();

		        
		     }

}
