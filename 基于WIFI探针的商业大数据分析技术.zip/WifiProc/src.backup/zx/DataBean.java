package zx;


public class DataBean {

    private String mac;//MAC��ַ
    private int rssi;//�ź�ǿ��
    private float range;//����
  
    public void setMac(String mac) {
         this.mac = mac;
     }
     public String getMac() {
         return mac;
     }

    public void setRssi(int rssi) {
         this.rssi = rssi;
     }
     public  int getRssi() {
         return rssi;
     }

    public void setRange(float range) {
         this.range = range;
     }
     public float getRange() {
         return range;
     }

}
