package zx;

import java.sql.Timestamp;

//�ڶ��ű������ݽṹ:MAC��Ծ�ȱ�
public class Table2 {
	int id;//MAC���
	String mac;//mac
	Timestamp lastTime;//�ϴ�����ʱ��
	float visitCycle;//��������
	int freq;//����Ƶ��
	boolean newClient;//���Ͽͻ�
	int activity;//��Ծ��
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public Timestamp getLastTime() {
		return lastTime;
	}
	public void setLastTime(Timestamp lastTime) {
		this.lastTime = lastTime;
	}
	public float getVisitCycle() {
		return visitCycle;
	}
	public void setVisitCycle(float visitCycle) {
		this.visitCycle = visitCycle;
	}
	public int getFreq() {
		return freq;
	}
	public void setFreq(int freq) {
		this.freq = freq;
	}
	public boolean isNewClient() {
		return newClient;
	}
	public void setNewClient(boolean newClient) {
		this.newClient = newClient;
	}
	public int getActivity() {
		return activity;
	}
	public void setActivity(int activity) {
		this.activity = activity;
	}

}
