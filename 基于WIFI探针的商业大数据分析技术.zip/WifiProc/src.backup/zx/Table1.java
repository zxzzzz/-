package zx;

import java.sql.Date;

//��һ�ű������ݽṹ��
public class Table1 {
	Date timeDate;// ����ʱ��
	int clientFlow;// ������
	int shopFlow;// �����
	float shopInflow;// �����
	float jumpFlow;// ������
	float deepFlow;// �����
	public Date getTimeDate() {
		return timeDate;
	}
	public void setTimeDate(Date timeDate) {
		this.timeDate = timeDate;
	}
	public int getClientFlow() {
		return clientFlow;
	}
	public void setClientFlow(int clientFlow) {
		this.clientFlow = clientFlow;
	}
	public int getShopFlow() {
		return shopFlow;
	}
	public void setShopFlow(int shopFlow) {
		this.shopFlow = shopFlow;
	}
	public float getShopInflow() {
		return shopInflow;
	}
	public void setShopInflow(float shopInflow) {
		this.shopInflow = shopInflow;
	}
	public float getJumpFlow() {
		return jumpFlow;
	}
	public void setJumpFlow(float jumpFlow) {
		this.jumpFlow = jumpFlow;
	}
	public float getDeepFlow() {
		return deepFlow;
	}
	public void setDeepFlow(float deepFlow) {
		this.deepFlow = deepFlow;
	}

	
}
