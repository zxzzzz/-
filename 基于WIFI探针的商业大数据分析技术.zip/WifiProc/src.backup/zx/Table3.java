package zx;

import java.sql.Date;

//�����ű������ݽṹ:פ��ʱ��ͳ�Ʊ�
public class Table3 {
	Date time;//��ʼʱ��
	String mac;//MAC
	float stayTime;//פ��ʱ��
	boolean jump;//�Ƿ�����
	boolean deep;//�Ƿ����
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public float getStayTime() {
		return stayTime;
	}
	public void setStayTime(float stayTime) {
		this.stayTime = stayTime;
	}
	public boolean isJump() {
		return jump;
	}
	public void setJump(boolean jump) {
		this.jump = jump;
	}
	public boolean isDeep() {
		return deep;
	}
	public void setDeep(boolean deep) {
		this.deep = deep;
	}
	

}
