package zx;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class Test1
 */
@WebServlet("/Test1")
public class Test1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Test1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DriverUnit.connectDB();
        Integer [][] data=new Integer[5][];
        data[0] =AnalysisUnit.clientFlow();
        data[1]=AnalysisUnit.shopFlow();
        data[2]=AnalysisUnit.shopInFlow();
        data[3]=AnalysisUnit.isNew();
        data[4]=AnalysisUnit.clientActivity();
//        {
//        	data1:[
//        	       {client:2,shop:3,shopIn:4}
//        	       {}
//        	       {}
//        	       ],
//        	old:3,
//        	new :4,
//        	activity:[high:2,mid:3,low:4,sleep:6]
//        }
        JSONObject sumJsonObject=new JSONObject();
        JSONArray jsonArray=new JSONArray();
        
        for (int i = 0; i < 24; i++) {
        	JSONObject j=new JSONObject();
        	j.put("client", data[0][i]);
        	j.put("shop", data[1][i]);
        	j.put("shopIn", data[2][i]);
             jsonArray.add(j);
     		}
        sumJsonObject.put("data1", jsonArray);
        sumJsonObject.put("old", data[3][1]);
        sumJsonObject.put("newClient", data[3][0]);
        JSONArray jArray=new JSONArray();
        JSONObject jObject=new JSONObject();
        jObject.put("high",data[4][0]);
        jObject.put("mid", data[4][1]);
        jObject.put("low",data[4][2]);
        jObject.put("sleep", data[4][3]);
        jArray.add(jObject);
        sumJsonObject.put("activity", jArray);
        System.out.println("Ҫ���͵�JSON����:"+sumJsonObject.toString());
		response.getWriter().write(sumJsonObject.toString());
		response.getWriter().flush();;
	}

}
