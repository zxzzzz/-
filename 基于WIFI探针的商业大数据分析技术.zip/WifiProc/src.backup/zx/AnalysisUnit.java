package zx;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;



//��������
public class AnalysisUnit {

	
	
		//�����յ���json���뵽���ݿ�
	
	public static void main(String[] args){
		DriverUnit.connectDB();
		System.out.println("��������");
		clientActivity();
		isNew();
		
		
		
		
		
	
	}
	
	//ͳ�ƿ�����  24Сʱ
	public static Integer[] clientFlow(){
		Integer[] client =new Integer[24];
		String clientQ="Select * from table1";
		for (int i = 0; i < client.length; i++) {
			client[i]=0;
		}
		int i=0;
		int count=0;
		try {
			ResultSet set=DriverUnit.stmt.executeQuery(clientQ);
			count=set.getRow();
			System.out.println("��¼����"+count);
			while (set.next()) {
				int c=set.getInt("clientFlow");
				client[i++]=c;
				System.out.println("clientFlow"+c);
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return client;
	}
	
	//ͳ������� 24Сʱ
		public static Integer[] shopFlow(){
			Integer[] shop =new Integer[24];
			String clientQ="Select * from table1";
			for (int i = 0; i < shop.length; i++) {
				shop[i]=0;
			}
			int i=0;
			int count=0;
			try {
				ResultSet set=DriverUnit.stmt.executeQuery(clientQ);
				count=set.getRow();
				System.out.println("��¼����"+count);
				while (set.next()) {
					int c=set.getInt("clientFlow");
					shop[i++]=c;
					System.out.println("shopClient"+c);
				}
				} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return shop;
		}
		
	
	//ͳ�������  24Сʱ
	public static Integer[] shopInFlow(){
		Integer[] shop =new Integer[24];
		String clientQ="Select * from table1";
		for (int i = 0; i < shop.length; i++) {
			shop[i]=0;
		}
		int i=0;
		int count=0;
		try {
			ResultSet set=DriverUnit.stmt.executeQuery(clientQ);
			count=set.getRow();
			System.out.println("��¼����"+count);
			while (set.next()) {
				
				int  c=set.getInt("shopInFlow");
				shop[i++]=c;
				System.out.println("shopClient"+c);
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return shop;
	}
	
	
	//��/�Ͽͻ�
	public static Integer[] isNew() {
		String newS="Select * from table2";
		ResultSet set;
		try {
			set = DriverUnit.stmt.executeQuery(newS);
			int newClient=0;
			int oldClient=0;
			while (set.next()) {
				int temp=set.getInt("newClient");
				if (temp==0) {
					
					newClient++;
					System.out.println("�¿ͻ�");
				}
				else {
					oldClient++;
					System.out.println("�Ͽͻ�");
				}
				
			}
			Integer []os=new Integer[2];
			os[0]=newClient;
			os[1]=oldClient;
			System.out.println("�¿ͻ�:"+newClient+"  �Ͽͻ�:"+oldClient);
			return os;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

	
//�ͻ���Ծ��
//	�߻�Ծ��:4
//	�л�Ծ��:3
//	�ͻ�Ծ��:2
//	��˯��Ծ��:1
	public static Integer[] clientActivity(){
		String activityS= "Select activity from table2 ";
		
		Integer [] activity=new Integer[4];
		for (int i = 0; i < activity.length; i++) {
			activity[i]=0;
		}
		try {
			ResultSet resultSet = DriverUnit.stmt.executeQuery(activityS);
			while (resultSet.next()) {
				int temp=resultSet.getInt(1);
				switch (temp) {
				case 4:
					activity[0]++;
					System.out.println("�߻�Ծ��");
					break;
				case 3:
					activity[1]++;
					System.out.println("�л�Ծ��");
					break;
				case 2:
					activity[2]++;
					System.out.println("�ͻ�Ծ��");
					break;
				case 1:
					activity[3]++;
					System.out.println("��˯��Ծ��");
					break;

				default:
					break;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("��Ծ�ȷֱ�Ϊ:"+activity[0]+","+activity[1]+","+activity[2]+","+activity[3]);
		return activity;
	}
	
	
	//��jsonתΪWifiBean
	public static WifiBean convertJSON(HttpServletRequest request){
		BufferedReader reader;
		try {
			reader = request.getReader();
			StringBuilder builder=new StringBuilder();
			String json;
			while ((json=reader.readLine())!=null) {
				builder.append(json);
				String json1=builder.toString();
				String targetJson=json1.substring(5);

				System.out.println("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn"+targetJson);
				JSONObject jsonObject=JSONObject.fromObject(targetJson);
				WifiBean wifiBean=new WifiBean();
				//	wifiBean.setAddr(jsonObject.getString("addr"));
				wifiBean.setTime(jsonObject.getString("time"));
				JSONArray jsonArray=jsonObject.getJSONArray("data");
				ArrayList<DataBean> dataBeans=new ArrayList<DataBean>();
				for (int i = 0; i < jsonArray.size();i++) {
					JSONObject item=jsonArray.getJSONObject(i);
					DataBean dataBean=new DataBean();
					String mac=item.getString("mac");
					//����MAC��sql�Ĳ�������в��ܴ�ð��
					mac=mac.replace(":", "");
					System.out.println("MACVVV"+mac);
					
					String  range=item.getString("range");
					float realRange=Float.parseFloat(range);
					String rssi=item.getString("rssi");
					int realRssi=Integer.parseInt(rssi);
					dataBean.setMac(mac);
					dataBean.setRange(realRange);
					dataBean.setRssi(realRssi);
					dataBeans.add(dataBean);
					
				}
				wifiBean.setData(dataBeans);
				return wifiBean;
		} 
			}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		
			
		}
		return null;
		
		
	}
	
	//פ��ʱ��
	public static float shopTime(){
		
		return 0;
	}
	//������
	public static float jump(){
		return 0;
	}
	//�����
	public static float deepVisit(){
		return 0;
	}
	
	
}
